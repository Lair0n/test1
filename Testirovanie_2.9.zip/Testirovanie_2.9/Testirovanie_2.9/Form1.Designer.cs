﻿namespace Testirovanie_2._9
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Matrix1 = new System.Windows.Forms.DataGridView();
            this.Matrix2 = new System.Windows.Forms.DataGridView();
            this.MatrixRes = new System.Windows.Forms.DataGridView();
            this.btnSum = new System.Windows.Forms.Button();
            this.btnSub = new System.Windows.Forms.Button();
            this.btnMult = new System.Windows.Forms.Button();
            this.btnDiv = new System.Windows.Forms.Button();
            this.btnTransp = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.txtRowsMatrix1 = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtColumnMatrix1 = new System.Windows.Forms.TextBox();
            this.txtColumnMatrix2 = new System.Windows.Forms.TextBox();
            this.txtRowsMatrix2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnRasm1 = new System.Windows.Forms.Button();
            this.btnRasm2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.Matrix1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Matrix2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatrixRes)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Matrix1
            // 
            this.Matrix1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Matrix1.Location = new System.Drawing.Point(23, 12);
            this.Matrix1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Matrix1.Name = "Matrix1";
            this.Matrix1.RowHeadersWidth = 51;
            this.Matrix1.RowTemplate.Height = 24;
            this.Matrix1.Size = new System.Drawing.Size(333, 302);
            this.Matrix1.TabIndex = 0;
            this.Matrix1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Matrix2
            // 
            this.Matrix2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Matrix2.Location = new System.Drawing.Point(460, 12);
            this.Matrix2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Matrix2.Name = "Matrix2";
            this.Matrix2.RowHeadersWidth = 51;
            this.Matrix2.RowTemplate.Height = 24;
            this.Matrix2.Size = new System.Drawing.Size(333, 302);
            this.Matrix2.TabIndex = 1;
            // 
            // MatrixRes
            // 
            this.MatrixRes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MatrixRes.Location = new System.Drawing.Point(213, 357);
            this.MatrixRes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MatrixRes.Name = "MatrixRes";
            this.MatrixRes.RowHeadersWidth = 51;
            this.MatrixRes.RowTemplate.Height = 24;
            this.MatrixRes.Size = new System.Drawing.Size(369, 321);
            this.MatrixRes.TabIndex = 2;
            // 
            // btnSum
            // 
            this.btnSum.Location = new System.Drawing.Point(14, 22);
            this.btnSum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSum.Name = "btnSum";
            this.btnSum.Size = new System.Drawing.Size(168, 46);
            this.btnSum.TabIndex = 3;
            this.btnSum.Text = "Сложение";
            this.btnSum.UseVisualStyleBackColor = true;
            this.btnSum.Click += new System.EventHandler(this.btnSum_Click);
            // 
            // btnSub
            // 
            this.btnSub.Location = new System.Drawing.Point(193, 22);
            this.btnSub.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSub.Name = "btnSub";
            this.btnSub.Size = new System.Drawing.Size(168, 46);
            this.btnSub.TabIndex = 4;
            this.btnSub.Text = "Вычитание";
            this.btnSub.UseVisualStyleBackColor = true;
            this.btnSub.Click += new System.EventHandler(this.btnSub_Click);
            // 
            // btnMult
            // 
            this.btnMult.Location = new System.Drawing.Point(14, 98);
            this.btnMult.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMult.Name = "btnMult";
            this.btnMult.Size = new System.Drawing.Size(168, 46);
            this.btnMult.TabIndex = 5;
            this.btnMult.Text = "Умножение";
            this.btnMult.UseVisualStyleBackColor = true;
            this.btnMult.Click += new System.EventHandler(this.btnMult_Click);
            // 
            // btnDiv
            // 
            this.btnDiv.Location = new System.Drawing.Point(193, 98);
            this.btnDiv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(168, 46);
            this.btnDiv.TabIndex = 6;
            this.btnDiv.Text = "Деление";
            this.btnDiv.UseVisualStyleBackColor = true;
            this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
            // 
            // btnTransp
            // 
            this.btnTransp.Location = new System.Drawing.Point(14, 171);
            this.btnTransp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTransp.Name = "btnTransp";
            this.btnTransp.Size = new System.Drawing.Size(168, 46);
            this.btnTransp.TabIndex = 7;
            this.btnTransp.Text = "Транспонирование 1";
            this.btnTransp.UseVisualStyleBackColor = true;
            this.btnTransp.Click += new System.EventHandler(this.btnTransp1_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(193, 171);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(168, 46);
            this.button6.TabIndex = 8;
            this.button6.Text = "Транспонирование 2";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.btnTransp2_Click);
            // 
            // txtRowsMatrix1
            // 
            this.txtRowsMatrix1.Location = new System.Drawing.Point(841, 75);
            this.txtRowsMatrix1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtRowsMatrix1.Name = "txtRowsMatrix1";
            this.txtRowsMatrix1.Size = new System.Drawing.Size(89, 22);
            this.txtRowsMatrix1.TabIndex = 9;
            this.txtRowsMatrix1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtColumnMatrix1
            // 
            this.txtColumnMatrix1.Location = new System.Drawing.Point(971, 75);
            this.txtColumnMatrix1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtColumnMatrix1.Name = "txtColumnMatrix1";
            this.txtColumnMatrix1.Size = new System.Drawing.Size(89, 22);
            this.txtColumnMatrix1.TabIndex = 11;
            // 
            // txtColumnMatrix2
            // 
            this.txtColumnMatrix2.Location = new System.Drawing.Point(971, 190);
            this.txtColumnMatrix2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtColumnMatrix2.Name = "txtColumnMatrix2";
            this.txtColumnMatrix2.Size = new System.Drawing.Size(89, 22);
            this.txtColumnMatrix2.TabIndex = 13;
            // 
            // txtRowsMatrix2
            // 
            this.txtRowsMatrix2.Location = new System.Drawing.Point(841, 190);
            this.txtRowsMatrix2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtRowsMatrix2.Name = "txtRowsMatrix2";
            this.txtRowsMatrix2.Size = new System.Drawing.Size(89, 22);
            this.txtRowsMatrix2.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(915, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 16);
            this.label1.TabIndex = 14;
            this.label1.Text = "Матрица 1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(837, 55);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "Строки";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(967, 55);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 16);
            this.label3.TabIndex = 16;
            this.label3.Text = "Столбцы";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(967, 170);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "Столбцы";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(837, 170);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 17;
            this.label5.Text = "Строки";
            // 
            // btnRasm1
            // 
            this.btnRasm1.Location = new System.Drawing.Point(1088, 71);
            this.btnRasm1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRasm1.Name = "btnRasm1";
            this.btnRasm1.Size = new System.Drawing.Size(100, 28);
            this.btnRasm1.TabIndex = 19;
            this.btnRasm1.Text = "Установить";
            this.btnRasm1.UseVisualStyleBackColor = true;
            this.btnRasm1.Click += new System.EventHandler(this.btnRasm1_Click);
            // 
            // btnRasm2
            // 
            this.btnRasm2.Location = new System.Drawing.Point(1088, 186);
            this.btnRasm2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRasm2.Name = "btnRasm2";
            this.btnRasm2.Size = new System.Drawing.Size(100, 28);
            this.btnRasm2.TabIndex = 20;
            this.btnRasm2.Text = "Установить";
            this.btnRasm2.UseVisualStyleBackColor = true;
            this.btnRasm2.Click += new System.EventHandler(this.btnRasm2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(915, 134);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 16);
            this.label6.TabIndex = 21;
            this.label6.Text = "Матрица 2";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Location = new System.Drawing.Point(827, 7);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(375, 102);
            this.panel1.TabIndex = 22;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Location = new System.Drawing.Point(827, 117);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(375, 102);
            this.panel2.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.btnSum);
            this.panel3.Controls.Add(this.btnSub);
            this.panel3.Controls.Add(this.btnMult);
            this.panel3.Controls.Add(this.btnDiv);
            this.panel3.Controls.Add(this.btnTransp);
            this.panel3.Controls.Add(this.button6);
            this.panel3.Location = new System.Drawing.Point(827, 227);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(375, 237);
            this.panel3.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 692);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnRasm2);
            this.Controls.Add(this.btnRasm1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtColumnMatrix2);
            this.Controls.Add(this.txtRowsMatrix2);
            this.Controls.Add(this.txtColumnMatrix1);
            this.Controls.Add(this.txtRowsMatrix1);
            this.Controls.Add(this.MatrixRes);
            this.Controls.Add(this.Matrix2);
            this.Controls.Add(this.Matrix1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Matrix1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Matrix2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatrixRes)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Matrix1;
        private System.Windows.Forms.DataGridView Matrix2;
        private System.Windows.Forms.DataGridView MatrixRes;
        private System.Windows.Forms.Button btnSum;
        private System.Windows.Forms.Button btnSub;
        private System.Windows.Forms.Button btnMult;
        private System.Windows.Forms.Button btnDiv;
        private System.Windows.Forms.Button btnTransp;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox txtRowsMatrix1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtColumnMatrix1;
        private System.Windows.Forms.TextBox txtColumnMatrix2;
        private System.Windows.Forms.TextBox txtRowsMatrix2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnRasm1;
        private System.Windows.Forms.Button btnRasm2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
    }
}

