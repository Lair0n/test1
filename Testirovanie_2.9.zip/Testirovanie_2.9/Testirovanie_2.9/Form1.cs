﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testirovanie_2._9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            int rows = Matrix1.RowCount;
            int columns = Matrix1.ColumnCount;

            // Проверяем, что размерности всех матриц совпадают
            if (rows == Matrix2.RowCount && columns == Matrix2.ColumnCount)
            {
                // Создаем третью матрицу для хранения результата
                MatrixRes.RowCount = rows;
                MatrixRes.ColumnCount = columns;

                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < columns; j++)
                    {
                        int value1 = Convert.ToInt32(Matrix1.Rows[i].Cells[j].Value);
                        int value2 = Convert.ToInt32(Matrix2.Rows[i].Cells[j].Value);

                        // Складываем соответствующие элементы двух матриц
                        int sum = value1 + value2;

                        // Записываем результат в третью матрицу
                        MatrixRes.Rows[i].Cells[j].Value = sum.ToString();
                    }
                }
            }
            else
            {
                MessageBox.Show("Размерности матриц не совпадают. Пожалуйста, установите одинаковые размерности для всех матриц.");
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            int rows = Matrix1.RowCount;
            int columns = Matrix1.ColumnCount;

            // Проверяем, что размерности всех матриц совпадают
            if (rows == Matrix2.RowCount && columns == Matrix2.ColumnCount)
            {
                // Создаем третью матрицу для хранения результата
                MatrixRes.RowCount = rows;
                MatrixRes.ColumnCount = columns;

                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < columns; j++)
                    {
                        int value1 = Convert.ToInt32(Matrix1.Rows[i].Cells[j].Value);
                        int value2 = Convert.ToInt32(Matrix2.Rows[i].Cells[j].Value);

                        // Вычитаем соответствующие элементы второй матрицы из первой
                        int difference = value1 - value2;

                        // Записываем результат в третью матрицу
                        MatrixRes.Rows[i].Cells[j].Value = difference.ToString();
                    }
                }
            }
            else
            {
                MessageBox.Show("Размерности матриц не совпадают. Пожалуйста, установите одинаковые размерности для всех матриц.");
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            int rowsA = Matrix1.RowCount;
            int columnsA = Matrix1.ColumnCount;
            int rowsB = Matrix2.RowCount;
            int columnsB = Matrix2.ColumnCount;

            // Проверяем, что количество столбцов первой матрицы равно количеству строк второй матрицы
            if (columnsA == rowsB)
            {
                // Создаем третью матрицу для хранения результата
                MatrixRes.RowCount = rowsA;
                MatrixRes.ColumnCount = columnsB;

                for (int i = 0; i < rowsA; i++)
                {
                    for (int j = 0; j < columnsB; j++)
                    {
                        int sum = 0;
                        for (int k = 0; k < columnsA; k++)
                        {
                            int value1 = Convert.ToInt32(Matrix1.Rows[i].Cells[k].Value);
                            int value2 = Convert.ToInt32(Matrix2.Rows[k].Cells[j].Value);

                            // Умножаем соответствующие элементы первой и второй матриц и суммируем результаты
                            sum += value1 * value2;
                        }

                        // Записываем результат в третью матрицу
                        MatrixRes.Rows[i].Cells[j].Value = sum.ToString();
                    }
                }
            }
            else
            {
                MessageBox.Show("Количество столбцов первой матрицы не равно количеству строк второй матрицы. Умножение невозможно.");
            }
        }

        public double[,] SetValuesMass(int rows, int columns, DataGridView dataGrid)
        {
            double[,] matrix = new double[rows, columns];
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    if (double.TryParse(dataGrid.Rows[i].Cells[j].Value.ToString(), out double value))
                    {
                        matrix[i, j] = value;
                    }
                    else
                    {
                        MessageBox.Show("Ошибка ввода данных");
                    }
                }
            }
            return matrix;
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            int rowsA = Matrix1.RowCount;
            int columnsA = Matrix1.ColumnCount;
            int rowsB = Matrix2.RowCount;
            int columnsB = Matrix2.ColumnCount;

            if (columnsA == rowsB)
            {
                // Заполнение матриц данными из DataGridView
                double[,] matrixA = SetValuesMass(rowsA, columnsA, Matrix1);
                double[,] matrixB = SetValuesMass(rowsB, columnsB, Matrix2);

                // Находим обратную матрицу для второй матрицы
                double[,] inverseB = InverseMatrix(matrixB);

                if (inverseB != null)
                {
                    // Умножаем первую матрицу на обратную второй матрицу
                    double[,] resultMatrix = new double[rowsA, columnsB];

                    for (int i = 0; i < rowsA; i++)
                    {
                        for (int j = 0; j < columnsB; j++)
                        {
                            for (int k = 0; k < columnsA; k++)
                            {
                                resultMatrix[i, j] += matrixA[i, k] * inverseB[k, j];
                            }
                        }
                    }

                    // Выводим результат в третью матрицу
                    MatrixRes.RowCount = rowsA;
                    MatrixRes.ColumnCount = columnsB;

                    for (int i = 0; i < rowsA; i++)
                    {
                        for (int j = 0; j < columnsB; j++)
                        {
                            MatrixRes.Rows[i].Cells[j].Value = resultMatrix[i, j].ToString();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Количество столбцов первой матрицы не равно количеству строк второй матрицы. Деление невозможно.");
            }
        }
        private double Determinant(double[,] matrix)
        {
            int n = (int)Math.Sqrt(matrix.Length);
            double det = 0;

            if (n == 1)
            {
                det = matrix[0, 0];
            }
            else if (n == 2)
            {
                det = matrix[0, 0] * matrix[1, 1] - matrix[0, 1] * matrix[1, 0];
            }
            else
            {
                for (int i = 0; i < n; i++)
                {
                    double[,] minor = new double[n - 1, n - 1];
                    for (int j = 1; j < n; j++)
                    {
                        for (int k = 0; k < n - 1; k++)
                        {
                            if (k < i)
                                minor[j - 1, k] = matrix[j, k];
                            else
                                minor[j - 1, k] = matrix[j, k + 1];
                        }
                    }
                    det += Math.Pow(-1, i) * matrix[0, i] * Determinant(minor);
                }
            }
            return det;
        }
        private double[,] InverseMatrix(double[,] matrix)//функция для нахождения обратной матрицы
        {
            int n = (int)Math.Sqrt(matrix.Length);
            double det = Determinant(matrix);

            if (det == 0)
            {
                MessageBox.Show("Матрица вырожденная, обратной матрицы не существует.");
                return null;
            }

            double[,] inverse = new double[n, n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    double[,] minor = new double[n - 1, n - 1];
                    for (int k = 0; k < n; k++)
                    {
                        for (int l = 0; l < n; l++)
                        {
                            if (k < i && l < j)
                                minor[k, l] = matrix[k, l];
                            else if (k < i && l > j)
                                minor[k, l - 1] = matrix[k, l];
                            else if (k > i && l < j)
                                minor[k - 1, l] = matrix[k, l];
                            else if (k > i && l > j)
                                minor[k - 1, l - 1] = matrix[k, l];
                        }
                    }
                    inverse[j, i] = Math.Pow(-1, i + j) * Determinant(minor) / det;
                }
            }

            return inverse;
        }

        private void btnTransp1_Click(object sender, EventArgs e)
        {
            double[,] matrixValues = GetMatrixValues(Matrix1);

            if (matrixValues != null)
            {
                double[,] transposedMatrix = TransposeMatrix(matrixValues);

                MatrixRes.Rows.Clear();
                MatrixRes.Columns.Clear();

                for (int i = 0; i < transposedMatrix.GetLength(0); i++)
                {
                    MatrixRes.Columns.Add("", "");
                }

                for (int i = 0; i < transposedMatrix.GetLength(0); i++)
                {
                    MatrixRes.Rows.Add();
                    for (int j = 0; j < transposedMatrix.GetLength(1); j++)
                    {
                        MatrixRes.Rows[i].Cells[j].Value = transposedMatrix[i, j];
                    }
                }
            }
        }
        private double[,] GetMatrixValues(DataGridView matrix)
        {
            int rows = matrix.RowCount;
            int cols = matrix.ColumnCount;

            double[,] values = new double[rows, cols];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (matrix.Rows[i].Cells[j].Value != null)
                    {
                        if (!double.TryParse(matrix.Rows[i].Cells[j].Value.ToString(), out values[i, j]))
                        {
                            // Обработка ошибки парсинга числа
                            MessageBox.Show("Ошибка при чтении чисел из матрицы.");
                            return null;
                        }
                    }
                    else
                    {
                        // Обработка пустых ячеек
                        MessageBox.Show("Пожалуйста, заполните все ячейки матрицы.");
                        return null;
                    }
                }
            }

            return values;
        }

        private double[,] TransposeMatrix(double[,] matrix)//Транспонирование матрицы
        {
            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);

            double[,] transposedMatrix = new double[cols, rows];

            for (int i = 0; i < cols; i++)
            {
                for (int j = 0; j < rows; j++)
                {
                    transposedMatrix[i, j] = matrix[j, i];
                }
            }

            return transposedMatrix;
        }

        private void btnTransp2_Click(object sender, EventArgs e)
        {
            double[,] matrixValues = GetMatrixValues(Matrix2);

            if (matrixValues != null)
            {
                double[,] transposedMatrix = TransposeMatrix(matrixValues);

                MatrixRes.Rows.Clear();
                MatrixRes.Columns.Clear();

                for (int i = 0; i < transposedMatrix.GetLength(0); i++)
                {
                    MatrixRes.Columns.Add("", "");
                }

                for (int i = 0; i < transposedMatrix.GetLength(0); i++)
                {
                    MatrixRes.Rows.Add();
                    for (int j = 0; j < transposedMatrix.GetLength(1); j++)
                    {
                        MatrixRes.Rows[i].Cells[j].Value = transposedMatrix[i, j];
                    }
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void btnRasm1_Click(object sender, EventArgs e)
        {
            SetMatrixSize(txtRowsMatrix1.Text, txtColumnMatrix1.Text, Matrix1);
        }

        private void btnRasm2_Click(object sender, EventArgs e)
        {
            SetMatrixSize(txtRowsMatrix2.Text, txtColumnMatrix2.Text, Matrix2);
        }

        public void SetMatrixSize(string row, string col, DataGridView dataGrid)//метод для установления размера матриц
        {
            int rows, columns;
            if (int.TryParse(row, out rows) && int.TryParse(col, out columns))
            {
                // Установка размерности матрицы
                dataGrid.RowCount = rows;
                dataGrid.ColumnCount = columns;

                // Очистка значений ячеек матрицы
                for (int i = 0; i < dataGrid.RowCount; i++)
                {
                    for (int j = 0; j < dataGrid.ColumnCount; j++)
                    {
                        dataGrid.Rows[i].Cells[j].Value = "";
                    }
                }
                dataGrid.AllowUserToAddRows = false;
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите целые числа в поля для количества строк и столбцов.");
            }
        }
    }
}
